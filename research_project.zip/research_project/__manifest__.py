{
    'name': 'Proyectos Investigación',
    'version': '1.0',
    'summary': "Prueba de Trabajos",
    'description': "Este un modulo especial para mostrar mi capacidad y aprendizajes de Odoo, y mostrar que soy capaz de trabajar aquí.",
    'depends': ['base'],
    'author': 'Roberto Vallecillos',
    'category': 'Custom',
    'data': [
        'views/project_view.xml',
        'security/ir.model.access.csv',
        'report/project_report.xml', 
        'report/project_report_template.xml',
        'data/ir_sequence_data.xml',
    ],
    'installable': True,
    'application': True,
}