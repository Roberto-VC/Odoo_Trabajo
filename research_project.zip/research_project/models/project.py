from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import date

class ResearchProject(models.Model):
    #Base del proyecto
    _name = 'research.project'
    _description = 'Proyecto de Investigación'

    # Campos del proyecto
    name = fields.Char(string='Nombre del Proyecto', required=True)
    code = fields.Char('Código', default=lambda self: self._generate_code(), copy=False)
    description = fields.Text(string='Descripción')
    start_date = fields.Date(string='Fecha de Inicio')
    end_date = fields.Date(string='Fecha Estimada de Finalización')
    budget = fields.Float(string='Presupuesto Asignado')
    #Selecciones de Estados y Prioridades.
    state = fields.Selection([
        ('nuevo', 'Nuevo'),
        ('en_progreso', 'En Progreso'),
        ('en_revision', 'En Revisión'),
        ('completado', 'Completado'),
        ('cancelado', 'Cancelado'),
    ], string='Estado', default='nuevo')
    priority = fields.Selection([
        ('1', 'Baja'),
        ('2', 'Media'),
        ('3', 'Alta'),
    ], string='Prioridad', default='2')
    investigator_ids = fields.Many2many('res.partner', string='Investigadores')
    leader_id = fields.Many2one('res.partner', string='Investigador Principal')

    # Campo computado: Días restantes para la finalización
    days_left = fields.Integer(string='Días Restantes', compute='_compute_days_left', store=True)
    additional_info = fields.Text(string="Información Adicional")

    @api.onchange('budget')
    def _onchange_budget(self):
        if self.budget and self.budget > 1000000:
            return {
                'warning': {
                    'title': "Presupuesto Elevado",
                    'message': "El presupuesto es bastante alto. Asegúrate de que esté aprobado por la dirección.",
                }
            }
        elif self.budget and self.budget < 0:
                        return {
                'warning': {
                    'title': "Presupuesto Negativo",
                    'message': "El presupuesto es negativo. Revisa que no hayan confundido nada.",
                }
            }



    #Funciones para cambiar el estado del proyecto.
    def action_do_progress(self):

        self.write({'state': 'en_progreso'})
        return True
    
    def action_do_revised(self):
        
        self.write({'state': 'en_revision'})
        return True
    
    def action_do_cancelled(self):
        
        self.write({'state': 'cancelado'})
        return True
    
    def action_do_new(self):
        self.write({'state': 'nuevo'})
        return True
    
    def action_do_complete(self):
        self.write({'state': 'completado'})
        return True


    #Función de fecha para comprobar que la fecha del fin no se pase de la fecha incial.
    @api.constrains('start_date', 'end_date')
    def _check_dates(self):
        for project in self:
            if project.start_date and project.end_date and project.start_date > project.end_date:
                #Si sucede, tira un error
                raise ValidationError('La fecha de inicio no puede ser posterior a la fecha de finalización.')
    
    # Secuencia automática para el campo 'code' par aun código unico.
    @api.model
    def _generate_code(self):
        # Esta es una función que genera un código único para el campo 'code'
        sequence = self.env['ir.sequence'].next_by_code('research.project.code')
        return sequence







